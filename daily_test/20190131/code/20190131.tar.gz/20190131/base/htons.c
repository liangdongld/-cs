#include <func.h>

int main()
{
    unsigned short port=0x1234,nport;
    nport=htons(port);
    return 0;
}

