#!/usr/bin/python
print 3+4
