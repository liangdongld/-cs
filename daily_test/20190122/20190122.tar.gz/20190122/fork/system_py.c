#include "func.h"

int main()
{
	system("python print.py");
	return 0;
}
