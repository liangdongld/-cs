#include "func.h"

int main()
{
	system("sleep 20");
	return 0;
}
