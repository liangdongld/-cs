#include "func.h"

int main()
{
	pid_t pid;
	pid=fork();
	printf("you can see me twice\n");
}
