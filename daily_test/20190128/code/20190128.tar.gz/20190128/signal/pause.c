#include <func.h>

int main()
{
    pause();
    return 0;
}

