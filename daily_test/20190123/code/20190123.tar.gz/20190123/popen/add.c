#include <stdio.h>

int main()
{
	int iNum1,iNum2;
	scanf("%d%d",&iNum1,&iNum2);
	printf("sum=%d\n",iNum1+iNum2);
	return 0;
}
